package com.example.dependencyinjection.model


class GetAllNewsResponse : ArrayList<GetAllNewsResponseItem>()