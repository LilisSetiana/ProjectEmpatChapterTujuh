package com.example.dependencyinjection.model

data class GetAllNewsResponseItem(
    val author: String,
    val createdAt: String,
    val description: String,
    val id: String,
    val image: String,
    val title: String
)


//
27