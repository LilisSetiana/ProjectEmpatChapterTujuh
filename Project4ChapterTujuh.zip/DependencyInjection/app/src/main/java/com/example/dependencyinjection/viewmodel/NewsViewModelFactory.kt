package com.example.dependencyinjection.viewmodel

class NewsViewModelFactory {
}