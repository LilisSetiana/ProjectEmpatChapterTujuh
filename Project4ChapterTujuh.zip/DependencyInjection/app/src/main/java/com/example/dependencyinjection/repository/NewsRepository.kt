package com.example.dependencyinjection.repository

import com.example.dependencyinjection.networking.ApiNewsServices

class NewsRepository constructor(private val apiNewsServices: ApiNewsServices) {
    fun getAllFilm() = apiNewsServices.getAllNews()
}